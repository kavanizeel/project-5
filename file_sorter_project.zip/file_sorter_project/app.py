from flask import Flask, render_template, request
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)

UPLOAD_FOLDER = 'uploads'
EXTENSION_MAP = {
    '.pdf': 'pdf',
    '.docx': 'doc',
    '.jpg': 'image',
    '.jpeg': 'image',
    '.png': 'image'
}

# Ensure subfolders exist
for folder in set(EXTENSION_MAP.values()):
    os.makedirs(os.path.join(UPLOAD_FOLDER, folder), exist_ok=True)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        file = request.files['file']
        if file:
            filename = secure_filename(file.filename)
            ext = os.path.splitext(filename)[1].lower()
            folder = EXTENSION_MAP.get(ext)
            if folder:
                save_path = os.path.join(UPLOAD_FOLDER, folder, filename)
                file.save(save_path)
                return f"File saved to {folder} folder."
            else:
                return "Unsupported file type."
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
